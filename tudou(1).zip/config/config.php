﻿<?php
	define("DB_HOST","127.0.0.1");
	define("DB_USER","root");
	define("DB_PWD","");
	define("DB_CHARSET","utf8");
	define("DB_DBNAME","tudou");
	define("APP_ROOT",realpath(dirname(__FILE__).'/../'));
	include(APP_ROOT.'/common/include.php');

?>



